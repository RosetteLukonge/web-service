/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lib_service;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import lib_service.lib_service;
import lib_service.lib_service_Stub;
import javax.microedition.midlet.*;

/**
 * @author appleinctechnologies
 */
public class mobileclient extends MIDlet implements CommandListener {

    lib_service proxy;

    private Form form;
    private Display display;
    private Command Next, login, clear, exit, back, select, add, clear1, exit1, insert;
    private List menu;
    private static String usermenu[] = {"Manage Book ", "Borrow book", "Manage member", "Manage Librarian"};
    private TextField sn, name, author_name, book_copies, year_edition;
    String serial_number = "";
    String book_name = "";
    String author = "";
    String copies = "";
    String edition = "";

    public mobileclient() {
        super();
        proxy = new lib_service_Stub();

        display = Display.getDisplay(this);
        Form form = new Form("Mainform");
        form.append("Labrary management system \n");
        form.append("Click next to visit the application \n");
        Next = new Command("NEXT", Command.ITEM, 0);
        form.addCommand(Next);
        form.setCommandListener(this);
        display.setCurrent(form);

    }

    public void buildMainScreen() {
        display = Display.getDisplay(this);
        Form form = new Form("Mainform");
        form.append("Labrary management system  \n");
        form.append("Visit the application\n");
        Next = new Command("NEXT", Command.ITEM, 0);
        form.addCommand(Next);
        form.setCommandListener(this);
        display.setCurrent(form);
    }

    private void showmenu() {
        menu = new List("Select what to do", Choice.IMPLICIT, usermenu, null);
        back = new Command("BACK", Command.BACK, 0);
        select = new Command("Select", Command.ITEM, 0);
        menu.addCommand(back);
        menu.addCommand(select);
        menu.setCommandListener(this);
        display.setCurrent(menu);
    }

    private void Inserting() {

        Form form = new Form("Add book");
        sn = new TextField("Serial Number:", "", 10, TextField.ANY);
        name = new TextField("Title:", "", 10, TextField.ANY);
        author_name = new TextField(" Author:", "", 10, TextField.ANY);
        book_copies = new TextField("Copies :", "", 10, TextField.ANY);
        year_edition = new TextField(" Edition year:", "", 10, TextField.ANY);

        form.append(sn);
        form.append(name);
        form.append(author_name);
        form.append(book_copies);
        form.append(year_edition);

        exit1 = new Command("Exit", Command.BACK, 0);
        clear = new Command("Clear", Command.SCREEN, 1);
        insert = new Command("Add book", Command.OK, 0);
        form.addCommand(insert);
        form.addCommand(exit1);
        form.addCommand(clear);
        form.setCommandListener(this);
        display.setCurrent(form);
    }

    public void startApp() {
    }

    public void pauseApp() {
    }

    public void destroyApp(boolean unconditional) {
        notifyDestroyed();
    }

    public void commandAction(Command c, Displayable d) {

        if (c == Next) {

            showmenu();

        }

        if (c == clear) {
            sn.setString("");
            name.setString("");
            author_name.setString("");
            book_copies.setString("");
            year_edition.setString("");

        }

        if (c == exit) {
            destroyApp(true);
        }

        if (c == back) {
            buildMainScreen();
        }

        if (c == select) {
            if (display.getCurrent() == menu) {

                if (menu.getSelectedIndex() == 1) {
                    Inserting();
                }

            }

        }
        if (c == select) {
            if (display.getCurrent() == menu) {

                Inserting();
            }

        }

        if (c == insert) {
            serial_number = sn.getString();
            book_name = name.getString();
            author = author_name.getString();
            copies = book_copies.getString();
            edition = year_edition.getString();

            try {

                new Thread(new Runnable() {
                    public void run() {
                        try {

                            proxy = new lib_service_Stub();
                            String result = proxy.add_book(serial_number, book_name, author, Integer.parseInt(copies), Integer.parseInt(edition));

                            if (result.equals("true")) {
                                Alert info = new Alert("Adding new book", " The record is added " + result, null, AlertType.INFO);
                                display.setCurrent(info);

                            } else {
                                Alert info = new Alert("Warning", " please enter valid values ", null, AlertType.WARNING);
                                display.setCurrent(info);
                            }
                            sn.setString("");
                            name.setString("");
                            author_name.setString("");
                            book_copies.setString("");
                            year_edition.setString("");

                        } catch (Exception e) {
                            println(e.toString());
                        }
                    }
                }
                ).start();

            } catch (Exception e) {
                println(e.toString());
            }

        }

    }

    private void println(String s) {
        form.append(s + "\n");
    }

}
