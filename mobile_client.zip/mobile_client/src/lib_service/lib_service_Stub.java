package lib_service;

import javax.xml.rpc.JAXRPCException;
import javax.xml.namespace.QName;
import javax.microedition.xml.rpc.Operation;
import javax.microedition.xml.rpc.Type;
import javax.microedition.xml.rpc.ComplexType;
import javax.microedition.xml.rpc.Element;

public class lib_service_Stub implements lib_service, javax.xml.rpc.Stub {

    private String[] _propertyNames;
    private Object[] _propertyValues;

    public lib_service_Stub() {
        _propertyNames = new String[]{ENDPOINT_ADDRESS_PROPERTY};
        _propertyValues = new Object[]{"http://localhost:8080/Library_app/lib_service"};
    }

    public void _setProperty(String name, Object value) {
        int size = _propertyNames.length;
        for (int i = 0; i < size; ++i) {
            if (_propertyNames[i].equals(name)) {
                _propertyValues[i] = value;
                return;
            }
        }
        String[] newPropNames = new String[size + 1];
        System.arraycopy(_propertyNames, 0, newPropNames, 0, size);
        _propertyNames = newPropNames;
        Object[] newPropValues = new Object[size + 1];
        System.arraycopy(_propertyValues, 0, newPropValues, 0, size);
        _propertyValues = newPropValues;

        _propertyNames[size] = name;
        _propertyValues[size] = value;
    }

    public Object _getProperty(String name) {
        for (int i = 0; i < _propertyNames.length; ++i) {
            if (_propertyNames[i].equals(name)) {
                return _propertyValues[i];
            }
        }
        if (ENDPOINT_ADDRESS_PROPERTY.equals(name) || USERNAME_PROPERTY.equals(name) || PASSWORD_PROPERTY.equals(name)) {
            return null;
        }
        if (SESSION_MAINTAIN_PROPERTY.equals(name)) {
            return new Boolean(false);
        }
        throw new JAXRPCException("Stub does not recognize property: " + name);
    }

    protected void _prepOperation(Operation op) {
        for (int i = 0; i < _propertyNames.length; ++i) {
            op.setProperty(_propertyNames[i], _propertyValues[i].toString());
        }
    }

    public String delete_bored(int bored_book_id) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            new Integer(bored_book_id)
        };

        Operation op = Operation.newInstance(_qname_operation_Delete_bored, _type_Delete_bored, _type_Delete_boredResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    public String delete_member(int member_id) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            new Integer(member_id)
        };

        Operation op = Operation.newInstance(_qname_operation_Delete_member, _type_Delete_member, _type_Delete_memberResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    public String add_librarian(String librarian_names) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            librarian_names
        };

        Operation op = Operation.newInstance(_qname_operation_Add_librarian, _type_Add_librarian, _type_Add_librarianResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    public String add_book(String serial_number, String book_name, String author, int copies, int edition_year) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            serial_number,
            book_name,
            author,
            new Integer(copies),
            new Integer(edition_year)
        };

        Operation op = Operation.newInstance(_qname_operation_Add_book, _type_Add_book, _type_Add_bookResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    public String view_librarian(String lib_id) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            lib_id
        };

        Operation op = Operation.newInstance(_qname_operation_view_librarian, _type_view_librarian, _type_view_librarianResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    public String add_member(String member_names) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            member_names
        };

        Operation op = Operation.newInstance(_qname_operation_Add_member, _type_Add_member, _type_Add_memberResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    public String view_member(String member_id) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            member_id
        };

        Operation op = Operation.newInstance(_qname_operation_view_member, _type_view_member, _type_view_memberResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    public String update_bored(int bored_book_id, String serial_number, int member_id, int lib_id, int status) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            new Integer(bored_book_id),
            serial_number,
            new Integer(member_id),
            new Integer(lib_id),
            new Integer(status)
        };

        Operation op = Operation.newInstance(_qname_operation_Update_bored, _type_Update_bored, _type_Update_boredResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    public String view_book(String serial_number) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            serial_number
        };

        Operation op = Operation.newInstance(_qname_operation_view_book, _type_view_book, _type_view_bookResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    public String update_book(String old_serial_number, String serial_number, String book_name, String author, int copies, int edition_year) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            old_serial_number,
            serial_number,
            book_name,
            author,
            new Integer(copies),
            new Integer(edition_year)
        };

        Operation op = Operation.newInstance(_qname_operation_update_book, _type_update_book, _type_update_bookResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    public String view_bored(int bored_book_id) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            new Integer(bored_book_id)
        };

        Operation op = Operation.newInstance(_qname_operation_view_bored, _type_view_bored, _type_view_boredResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    public String delete_librarian(int lib_id) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            new Integer(lib_id)
        };

        Operation op = Operation.newInstance(_qname_operation_Delete_librarian, _type_Delete_librarian, _type_Delete_librarianResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    public String hello(String name) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            name
        };

        Operation op = Operation.newInstance(_qname_operation_hello, _type_hello, _type_helloResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    public String add_bored(String serial_number, int member_id, int lib_id, int status) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            serial_number,
            new Integer(member_id),
            new Integer(lib_id),
            new Integer(status)
        };

        Operation op = Operation.newInstance(_qname_operation_Add_bored, _type_Add_bored, _type_Add_boredResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    public String delete_book(String serial_number) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            serial_number
        };

        Operation op = Operation.newInstance(_qname_operation_Delete_book, _type_Delete_book, _type_Delete_bookResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    public String update_member(int member_id, String member_names) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            new Integer(member_id),
            member_names
        };

        Operation op = Operation.newInstance(_qname_operation_update_member, _type_update_member, _type_update_memberResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    public String update_librarian(int lib_id, String librarian_names) throws java.rmi.RemoteException {
        Object inputObject[] = new Object[]{
            new Integer(lib_id),
            librarian_names
        };

        Operation op = Operation.newInstance(_qname_operation_update_librarian, _type_update_librarian, _type_update_librarianResponse);
        _prepOperation(op);
        op.setProperty(Operation.SOAPACTION_URI_PROPERTY, "");
        Object resultObj;
        try {
            resultObj = op.invoke(inputObject);
        } catch (JAXRPCException e) {
            Throwable cause = e.getLinkedCause();
            if (cause instanceof java.rmi.RemoteException) {
                throw (java.rmi.RemoteException) cause;
            }
            throw e;
        }

        return (String) ((Object[]) resultObj)[0];
    }

    protected static final QName _qname_operation_Add_book = new QName("http://service_pack/", "Add_book");
    protected static final QName _qname_operation_view_librarian = new QName("http://service_pack/", "view_librarian");
    protected static final QName _qname_operation_Delete_bored = new QName("http://service_pack/", "Delete_bored");
    protected static final QName _qname_operation_Add_librarian = new QName("http://service_pack/", "Add_librarian");
    protected static final QName _qname_operation_Delete_member = new QName("http://service_pack/", "Delete_member");
    protected static final QName _qname_operation_Update_bored = new QName("http://service_pack/", "Update_bored");
    protected static final QName _qname_operation_view_bored = new QName("http://service_pack/", "view_bored");
    protected static final QName _qname_operation_view_book = new QName("http://service_pack/", "view_book");
    protected static final QName _qname_operation_update_book = new QName("http://service_pack/", "update_book");
    protected static final QName _qname_operation_Add_member = new QName("http://service_pack/", "Add_member");
    protected static final QName _qname_operation_view_member = new QName("http://service_pack/", "view_member");
    protected static final QName _qname_operation_Add_bored = new QName("http://service_pack/", "Add_bored");
    protected static final QName _qname_operation_update_member = new QName("http://service_pack/", "update_member");
    protected static final QName _qname_operation_update_librarian = new QName("http://service_pack/", "update_librarian");
    protected static final QName _qname_operation_Delete_book = new QName("http://service_pack/", "Delete_book");
    protected static final QName _qname_operation_hello = new QName("http://service_pack/", "hello");
    protected static final QName _qname_operation_Delete_librarian = new QName("http://service_pack/", "Delete_librarian");
    protected static final QName _qname_update_librarianResponse = new QName("http://service_pack/", "update_librarianResponse");
    protected static final QName _qname_Add_bookResponse = new QName("http://service_pack/", "Add_bookResponse");
    protected static final QName _qname_view_memberResponse = new QName("http://service_pack/", "view_memberResponse");
    protected static final QName _qname_Add_librarianResponse = new QName("http://service_pack/", "Add_librarianResponse");
    protected static final QName _qname_update_memberResponse = new QName("http://service_pack/", "update_memberResponse");
    protected static final QName _qname_view_librarian = new QName("http://service_pack/", "view_librarian");
    protected static final QName _qname_Add_librarian = new QName("http://service_pack/", "Add_librarian");
    protected static final QName _qname_Add_boredResponse = new QName("http://service_pack/", "Add_boredResponse");
    protected static final QName _qname_Delete_member = new QName("http://service_pack/", "Delete_member");
    protected static final QName _qname_Update_bored = new QName("http://service_pack/", "Update_bored");
    protected static final QName _qname_view_bored = new QName("http://service_pack/", "view_bored");
    protected static final QName _qname_view_book = new QName("http://service_pack/", "view_book");
    protected static final QName _qname_helloResponse = new QName("http://service_pack/", "helloResponse");
    protected static final QName _qname_view_librarianResponse = new QName("http://service_pack/", "view_librarianResponse");
    protected static final QName _qname_view_bookResponse = new QName("http://service_pack/", "view_bookResponse");
    protected static final QName _qname_Delete_bookResponse = new QName("http://service_pack/", "Delete_bookResponse");
    protected static final QName _qname_update_librarian = new QName("http://service_pack/", "update_librarian");
    protected static final QName _qname_view_boredResponse = new QName("http://service_pack/", "view_boredResponse");
    protected static final QName _qname_hello = new QName("http://service_pack/", "hello");
    protected static final QName _qname_update_bookResponse = new QName("http://service_pack/", "update_bookResponse");
    protected static final QName _qname_Add_book = new QName("http://service_pack/", "Add_book");
    protected static final QName _qname_Delete_librarianResponse = new QName("http://service_pack/", "Delete_librarianResponse");
    protected static final QName _qname_Delete_bored = new QName("http://service_pack/", "Delete_bored");
    protected static final QName _qname_Update_boredResponse = new QName("http://service_pack/", "Update_boredResponse");
    protected static final QName _qname_update_book = new QName("http://service_pack/", "update_book");
    protected static final QName _qname_Add_member = new QName("http://service_pack/", "Add_member");
    protected static final QName _qname_view_member = new QName("http://service_pack/", "view_member");
    protected static final QName _qname_Add_bored = new QName("http://service_pack/", "Add_bored");
    protected static final QName _qname_Delete_memberResponse = new QName("http://service_pack/", "Delete_memberResponse");
    protected static final QName _qname_update_member = new QName("http://service_pack/", "update_member");
    protected static final QName _qname_Delete_book = new QName("http://service_pack/", "Delete_book");
    protected static final QName _qname_Add_memberResponse = new QName("http://service_pack/", "Add_memberResponse");
    protected static final QName _qname_Delete_boredResponse = new QName("http://service_pack/", "Delete_boredResponse");
    protected static final QName _qname_Delete_librarian = new QName("http://service_pack/", "Delete_librarian");
    protected static final Element _type_Add_librarian;
    protected static final Element _type_view_librarian;
    protected static final Element _type_Delete_book;
    protected static final Element _type_Add_bored;
    protected static final Element _type_view_memberResponse;
    protected static final Element _type_Add_librarianResponse;
    protected static final Element _type_Delete_librarianResponse;
    protected static final Element _type_update_librarianResponse;
    protected static final Element _type_update_memberResponse;
    protected static final Element _type_update_librarian;
    protected static final Element _type_Delete_memberResponse;
    protected static final Element _type_Delete_boredResponse;
    protected static final Element _type_Delete_librarian;
    protected static final Element _type_view_member;
    protected static final Element _type_update_bookResponse;
    protected static final Element _type_Delete_bookResponse;
    protected static final Element _type_Update_bored;
    protected static final Element _type_view_bookResponse;
    protected static final Element _type_hello;
    protected static final Element _type_Add_member;
    protected static final Element _type_update_member;
    protected static final Element _type_helloResponse;
    protected static final Element _type_view_bored;
    protected static final Element _type_Update_boredResponse;
    protected static final Element _type_view_boredResponse;
    protected static final Element _type_Add_bookResponse;
    protected static final Element _type_view_book;
    protected static final Element _type_Delete_member;
    protected static final Element _type_view_librarianResponse;
    protected static final Element _type_Add_book;
    protected static final Element _type_Add_boredResponse;
    protected static final Element _type_Add_memberResponse;
    protected static final Element _type_Delete_bored;
    protected static final Element _type_update_book;

    static {
        _type_update_librarianResponse = new Element(_qname_update_librarianResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_Add_bookResponse = new Element(_qname_Add_bookResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_view_memberResponse = new Element(_qname_view_memberResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_Add_librarianResponse = new Element(_qname_Add_librarianResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_update_memberResponse = new Element(_qname_update_memberResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_view_librarian = new Element(_qname_view_librarian, _complexType(new Element[]{
            new Element(new QName("", "lib_id"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_Add_librarian = new Element(_qname_Add_librarian, _complexType(new Element[]{
            new Element(new QName("", "librarian_names"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_Add_boredResponse = new Element(_qname_Add_boredResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_Delete_member = new Element(_qname_Delete_member, _complexType(new Element[]{
            new Element(new QName("", "member_id"), Type.INT)}), 1, 1, false);
        _type_Update_bored = new Element(_qname_Update_bored, _complexType(new Element[]{
            new Element(new QName("", "bored_book_id"), Type.INT),
            new Element(new QName("", "serial_number"), Type.STRING, 0, 1, false),
            new Element(new QName("", "member_id"), Type.INT),
            new Element(new QName("", "lib_id"), Type.INT),
            new Element(new QName("", "status"), Type.INT)}), 1, 1, false);
        _type_view_bored = new Element(_qname_view_bored, _complexType(new Element[]{
            new Element(new QName("", "bored_book_id "), Type.INT)}), 1, 1, false);
        _type_view_book = new Element(_qname_view_book, _complexType(new Element[]{
            new Element(new QName("", "serial_number"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_helloResponse = new Element(_qname_helloResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_view_librarianResponse = new Element(_qname_view_librarianResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_view_bookResponse = new Element(_qname_view_bookResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_Delete_bookResponse = new Element(_qname_Delete_bookResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_update_librarian = new Element(_qname_update_librarian, _complexType(new Element[]{
            new Element(new QName("", "lib_id"), Type.INT),
            new Element(new QName("", "librarian_names"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_view_boredResponse = new Element(_qname_view_boredResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_hello = new Element(_qname_hello, _complexType(new Element[]{
            new Element(new QName("", "name"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_update_bookResponse = new Element(_qname_update_bookResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_Add_book = new Element(_qname_Add_book, _complexType(new Element[]{
            new Element(new QName("", "serial_number"), Type.STRING, 0, 1, false),
            new Element(new QName("", "book_name"), Type.STRING, 0, 1, false),
            new Element(new QName("", "author"), Type.STRING, 0, 1, false),
            new Element(new QName("", "copies"), Type.INT),
            new Element(new QName("", "edition_year"), Type.INT)}), 1, 1, false);
        _type_Delete_librarianResponse = new Element(_qname_Delete_librarianResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_Delete_bored = new Element(_qname_Delete_bored, _complexType(new Element[]{
            new Element(new QName("", "bored_book_id "), Type.INT)}), 1, 1, false);
        _type_Update_boredResponse = new Element(_qname_Update_boredResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_update_book = new Element(_qname_update_book, _complexType(new Element[]{
            new Element(new QName("", "old_serial_number"), Type.STRING, 0, 1, false),
            new Element(new QName("", "serial_number"), Type.STRING, 0, 1, false),
            new Element(new QName("", "book_name"), Type.STRING, 0, 1, false),
            new Element(new QName("", "author"), Type.STRING, 0, 1, false),
            new Element(new QName("", "copies"), Type.INT),
            new Element(new QName("", "edition_year"), Type.INT)}), 1, 1, false);
        _type_Add_member = new Element(_qname_Add_member, _complexType(new Element[]{
            new Element(new QName("", "member_names"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_view_member = new Element(_qname_view_member, _complexType(new Element[]{
            new Element(new QName("", "member_id"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_Add_bored = new Element(_qname_Add_bored, _complexType(new Element[]{
            new Element(new QName("", "serial_number"), Type.STRING, 0, 1, false),
            new Element(new QName("", "member_id"), Type.INT),
            new Element(new QName("", "lib_id"), Type.INT),
            new Element(new QName("", "status"), Type.INT)}), 1, 1, false);
        _type_Delete_memberResponse = new Element(_qname_Delete_memberResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_update_member = new Element(_qname_update_member, _complexType(new Element[]{
            new Element(new QName("", "member_id"), Type.INT),
            new Element(new QName("", "member_names"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_Delete_book = new Element(_qname_Delete_book, _complexType(new Element[]{
            new Element(new QName("", "serial_number"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_Add_memberResponse = new Element(_qname_Add_memberResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_Delete_boredResponse = new Element(_qname_Delete_boredResponse, _complexType(new Element[]{
            new Element(new QName("", "return"), Type.STRING, 0, 1, false)}), 1, 1, false);
        _type_Delete_librarian = new Element(_qname_Delete_librarian, _complexType(new Element[]{
            new Element(new QName("", "lib_id"), Type.INT)}), 1, 1, false);
    }

    private static ComplexType _complexType(Element[] elements) {
        ComplexType result = new ComplexType();
        result.elements = elements;
        return result;
    }
}
