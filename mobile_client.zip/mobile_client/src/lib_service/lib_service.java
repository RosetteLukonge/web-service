package lib_service;

import javax.xml.namespace.QName;

public interface lib_service extends java.rmi.Remote {

    /**
     *
     */
    public String delete_bored(int bored_book_id) throws java.rmi.RemoteException;

    /**
     *
     */
    public String delete_member(int member_id) throws java.rmi.RemoteException;

    /**
     *
     */
    public String add_librarian(String librarian_names) throws java.rmi.RemoteException;

    /**
     *
     */
    public String add_book(String serial_number, String book_name, String author, int copies, int edition_year) throws java.rmi.RemoteException;

    /**
     *
     */
    public String view_librarian(String lib_id) throws java.rmi.RemoteException;

    /**
     *
     */
    public String add_member(String member_names) throws java.rmi.RemoteException;

    /**
     *
     */
    public String view_member(String member_id) throws java.rmi.RemoteException;

    /**
     *
     */
    public String update_bored(int bored_book_id, String serial_number, int member_id, int lib_id, int status) throws java.rmi.RemoteException;

    /**
     *
     */
    public String view_book(String serial_number) throws java.rmi.RemoteException;

    /**
     *
     */
    public String update_book(String old_serial_number, String serial_number, String book_name, String author, int copies, int edition_year) throws java.rmi.RemoteException;

    /**
     *
     */
    public String view_bored(int bored_book_id) throws java.rmi.RemoteException;

    /**
     *
     */
    public String delete_librarian(int lib_id) throws java.rmi.RemoteException;

    /**
     *
     */
    public String hello(String name) throws java.rmi.RemoteException;

    /**
     *
     */
    public String add_bored(String serial_number, int member_id, int lib_id, int status) throws java.rmi.RemoteException;

    /**
     *
     */
    public String delete_book(String serial_number) throws java.rmi.RemoteException;

    /**
     *
     */
    public String update_member(int member_id, String member_names) throws java.rmi.RemoteException;

    /**
     *
     */
    public String update_librarian(int lib_id, String librarian_names) throws java.rmi.RemoteException;

}
