/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service_pack;

/**
 *
 * @author USER717
 */
public class BookClass {
    
   public String serialNumber;
   public String bookName;
   public String author;
   public String copies;
   public String editionYear;
   
   public BookClass (String serialNumber, String bookName, String author, String copies, String editionYear) {
        this.serialNumber = serialNumber;
        this.author =  author;
        this.bookName = bookName;
        this.copies = copies;
        this.editionYear = editionYear;
        
        }
}
