/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service_pack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author appleinctechnologies
 */
@WebService(serviceName = "lib_service")
public class lib_service {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Add_book")
    public String Add_book(@WebParam(name = "serial_number") String serial_number, @WebParam(name = "book_name") String book_name, @WebParam(name = "author") String author, @WebParam(name = "copies") int copies, @WebParam(name = "edition_year") int edition_year) {
        //TODO write your implementation code here:
        String bool = "false";
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:8889/library", "root", "root");
            PreparedStatement ts = con.prepareStatement("INSERT INTO book values(?,?, ?, ?, ?)");
            ts.setString(1, serial_number);
            ts.setString(2, book_name);
            ts.setString(3, author);
            ts.setInt(4, copies);
            ts.setInt(5, edition_year);
            ts.executeUpdate();
            bool = "true";
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            bool = e.getLocalizedMessage();
        }

        return bool;
    }
 
    @WebMethod(operationName = "Delete_book")
    public String Delete_book(@WebParam(name = "serial_number") String serial_number) {
        //TODO write your implementation code here:
        String bool = "false";
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:8889/library", "root", "root");
            PreparedStatement ts = con.prepareStatement("DELETE FROM book where serial_number=?");
            ts.setString(1, serial_number);
            ts.executeUpdate();
            bool = "true";
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            bool = e.getLocalizedMessage();
        }

        return bool;
    }
    
    @WebMethod(operationName = "view_book")
    public String View_book(@WebParam(name = "serial_number") String serial_number) {
        //TODO write your implementation code here:
        String bool = "false";
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:8889/library", "root", "root");
            PreparedStatement ts = con.prepareStatement("SELECT * FROM book where serial_number=?");
            ts.setString(1, serial_number);
            ts.executeQuery();
            bool = "true";
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            bool = e.getLocalizedMessage();
        }

        return bool;
    }
    
    @WebMethod(operationName = "update_book")
    public String update_book(@WebParam(name = "old_serial_number") String old_serial_number,@WebParam(name = "serial_number") String serial_number, @WebParam(name = "book_name") String book_name, @WebParam(name = "author") String author, @WebParam(name = "copies") int copies, @WebParam(name = "edition_year") int edition_year) {
        //TODO write your implementation code here:
        String bool = "false";
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:8889/library", "root", "root");
            PreparedStatement ts = con.prepareStatement("UPDATE book set serial_number=?, book_name=?,author=?,copies=?,edition_year=? WHERE serial_number=?");
            ts.setString(1, serial_number);
            ts.setString(2, book_name);
            ts.setString(3, author);
            ts.setInt(4, copies);
            ts.setInt(5, edition_year);
            ts.setString(6, old_serial_number);
            ts.executeUpdate();
            bool = "true";
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            bool = e.getLocalizedMessage();
        }

        return bool;
    }

    @WebMethod(operationName = "Add_member")
    public String Add_member(@WebParam(name = "member_names") String member_names){
        //TODO write your implementation code here:
        String bool = "false";
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:8889/library", "root", "root");
            PreparedStatement ts = con.prepareStatement("INSERT INTO members(member_names) values(?)");
            ts.setString(1, member_names);
            ts.executeUpdate();
            bool = "true";
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            bool = e.getLocalizedMessage();
        }

        return bool;
    }
    
    
@WebMethod(operationName = "Delete_member")
    public String Delete_member(@WebParam(name = "member_id") int member_id){
        //TODO write your implementation code here:
        String bool = "false";
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:8889/library", "root", "root");
            PreparedStatement ts = con.prepareStatement("DELETE FROM members where member_id=?");
            ts.setInt(1, member_id);
            ts.executeUpdate();
            bool = "true";
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            bool = e.getLocalizedMessage();
        }

        return bool;
    }
   
    @WebMethod(operationName = "view_member")
    public String View_member(@WebParam(name = "member_id") String member_id) {
        //TODO write your implementation code here:
        String bool = "false";
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:8889/library", "root", "root");
            PreparedStatement ts = con.prepareStatement("SELECT * FROM members WHERE member_id=?");
            ts.setString(1, member_id);
            ts.executeQuery();
            bool = "true";
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            bool = e.getLocalizedMessage();
        }

        return bool;
    }
    @WebMethod(operationName = "update_member")
    public String Update_member(@WebParam(name = "member_id") int member_id,@WebParam(name = "member_names") String member_names){
        //TODO write your implementation code here:
        String bool = "false";
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:8889/library", "root", "root");
            PreparedStatement ts = con.prepareStatement("UPDATE members set member_names=?");
            ts.setString(1, member_names);
            ts.executeUpdate();
            bool = "true";
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            bool = e.getLocalizedMessage();
        }

        return bool;
    }
    
  @WebMethod(operationName = "Add_librarian")
    public String Add_librarian(@WebParam(name = "librarian_names") String librarian_names){
        //TODO write your implementation code here:
        String bool = "false";
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:8889/library", "root", "root");
            PreparedStatement ts = con.prepareStatement("INSERT INTO librarian(librarian_names) values(?)");
            ts.setString(1, librarian_names);
            ts.executeUpdate();
            bool = "true";
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            bool = e.getLocalizedMessage();
        }

        return bool;
    }
    @WebMethod(operationName = "Delete_librarian")
    public String Delete_librarian(@WebParam(name = "lib_id") int lib_id){
        //TODO write your implementation code here:
        String bool = "false";
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:8889/library", "root", "root");
            PreparedStatement ts = con.prepareStatement("DELETE FROM librarian where lib_id=?");
            ts.setInt(1, lib_id);
            ts.executeUpdate();
            bool = "true";
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            bool = e.getLocalizedMessage();
        }

        return bool;
    }
    
    @WebMethod(operationName = "view_librarian")
    public String View_librarian(@WebParam(name = "lib_id") String lib_id) {
        //TODO write your implementation code here:
        String bool = "false";
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:8889/library", "root", "root");
            PreparedStatement ts = con.prepareStatement("SELECT * FROM librarian WHERE lib_id=?");
            ts.setString(1, lib_id);
            ts.executeQuery();
            bool = "true";
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            bool = e.getLocalizedMessage();
        }

        return bool;
    }
    @WebMethod(operationName = "update_librarian")
    public String Update_librarian(@WebParam(name = "lib_id") int lib_id,@WebParam(name = "librarian_names") String librarian_names){
        //TODO write your implementation code here:
        String bool = "false";
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:8889/library", "root", "root");
            PreparedStatement ts = con.prepareStatement("UPDATE librarian set librarian_names=?");
            ts.setString(1, librarian_names);
            ts.executeUpdate();
            bool = "true";
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            bool = e.getLocalizedMessage();
        }

        return bool;
    }
    
    
    @WebMethod(operationName = "Add_bored")
    public String Add_bored(@WebParam(name = "serial_number") String serial_number,@WebParam(name = "member_id") int member_id, @WebParam(name = "lib_id") int lib_id,@WebParam(name = "status") int status){
        //TODO write your implementation code here:
        String bool = "false";
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:8889/library", "root", "root");
            PreparedStatement ts = con.prepareStatement("INSERT INTO bored_book(serial_number,member_id,lib_id,status) values(?,?,?,?)");
            ts.setString(1, serial_number);
            ts.setInt(2, member_id);
            ts.setInt(3, lib_id);
            ts.setInt(4, status);
            ts.executeUpdate();
            bool = "true";
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            bool = e.getLocalizedMessage();
        }

        return bool;
    }
  @WebMethod(operationName = "Delete_bored")
    public String Delete_bored(@WebParam(name = "bored_book_id ") int bored_book_id ){
        //TODO write your implementation code here:
        String bool = "false";
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:8889/library", "root", "root");
            PreparedStatement ts = con.prepareStatement("DELETE FROM bored_book  where bored_book_id =?");
            ts.setInt(1, bored_book_id );
            ts.executeUpdate();
            bool = "true";
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            bool = e.getLocalizedMessage();
        }

        return bool;
    }
 @WebMethod(operationName = "view_bored")
    public String View_bored(@WebParam(name = "bored_book_id ") int bored_book_id ){
        //TODO write your implementation code here:
        String bool = "false";
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:8889/library", "root", "root");
            PreparedStatement ts = con.prepareStatement("SELECT * FROM bored_book  WHERE bored_book_id =?");
            ts.setInt(1, bored_book_id );
            ts.executeQuery();
            bool = "true";
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            bool = e.getLocalizedMessage();
        }

        return bool;
    }
@WebMethod(operationName = "Update_bored")
    public String Update_bored(@WebParam(name = "bored_book_id") int bored_book_id, @WebParam(name = "serial_number") String serial_number,@WebParam(name = "member_id") int member_id, @WebParam(name = "lib_id") int lib_id,@WebParam(name = "status") int status){
        //TODO write your implementation code here:
        String bool = "false";
        Connection con;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:8889/library", "root", "root");
            PreparedStatement ts = con.prepareStatement("UPDATE  bored_book set serial_number=?,member_id=?,lib_id=?,status=? WHERE bored_book_id=?");
            ts.setString(1, serial_number);
            ts.setInt(2, member_id);
            ts.setInt(3, lib_id);
            ts.setInt(4, status);
            ts.setInt(5, bored_book_id);
            ts.executeUpdate();
            bool = "true";
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            bool = e.getLocalizedMessage();
        }

        return bool;
    }

}
